# Reconstrução — Protocolo de Recuperação Clavícula ORIF

## Deploy na Vercel (3 passos)

### Opção A — Via GitHub (recomendada)
1. Crie um repositório no GitHub e faça upload destes arquivos
2. Vá em [vercel.com/new](https://vercel.com/new)
3. Importe o repositório → Vercel detecta Vite automaticamente → Deploy!

### Opção B — Via CLI
```bash
npm install
npx vercel
```

### Opção C — Drag & drop
1. Rode `npm install && npm run build` localmente
2. Arraste a pasta `dist/` em [vercel.com/new](https://vercel.com/new)

Pronto — você terá um link público tipo `seu-projeto.vercel.app`
