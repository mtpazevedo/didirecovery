import { useState, useEffect, useRef } from "react";

const FONTS_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300;1,400&family=JetBrains+Mono:wght@300;400&display=swap');
`;

const PHASES = [
  {
    id: 0,
    week: "Semanas 0 – 2",
    title: "Silêncio",
    subtitle: "Proteção & Controle da Dor",
    epigraph: {
      text: "A paciência é a companheira da sabedoria.",
      author: "Santo Agostinho",
    },
    poem: "Como o concreto que cura na sombra, sua clavícula agora exige quietude. A placa de titânio sustenta — você descansa. Há engenharia também na pausa.",
    insight: "O titânio da sua placa é o mesmo material usado no Guggenheim de Bilbao. Seu corpo agora carrega arquitetura.",
    scienceNote: "O calo ósseo primário começa a se formar nas primeiras 48–72h. Citocinas inflamatórias (IL-1, IL-6, TNF-α) recrutam células mesenquimais que se diferenciarão em osteoblastos. A inflamação controlada NÃO é sua inimiga — é a primeira fase da construção. (Einhorn & Gerstenfeld, Nature Reviews Rheumatology, 2015)",
    physio: [
      { name: "Pendulares de Codman", how: "Incline o tronco para frente. Deixe o braço operado pendurar relaxado. Pequenos círculos — o movimento nasce do quadril, não do ombro.", sets: "10× horário + 10× anti-horário · 3×/dia", icon: "◯" },
      { name: "Flexo-extensão de Cotovelo", how: "Braço na tipoia. Flexione e estenda o cotovelo lentamente. Previne rigidez e melhora circulação.", sets: "15 repetições · 4×/dia", icon: "⟷" },
      { name: "Mobilização de Mão e Punho", how: "Abra e feche a mão com intenção. Circundução do punho. Previne edema e síndrome compartimental.", sets: "A cada 2 horas", icon: "✦" },
      { name: "Retração Escapular Sutil", how: "Sentada ereta, junte as escápulas — como se quisesse segurar um lápis entre elas. 5 segundos. Ativa estabilizadores sem sobrecarregar.", sets: "10 repetições · 3×/dia", icon: "◇" },
    ],
    breathing: [
      { name: "Respiração 4-7-8 (Dr. Andrew Weil)", how: "Inspire — 4 tempos. Segure — 7 tempos. Expire pela boca — 8 tempos. Ativa o parassimpático. Reduz percepção de dor.", when: "4 ciclos · 3×/dia" },
      { name: "Expansão Costal Lateral", how: "Mãos nas laterais das costelas. Inspire expandindo para os lados — não para cima. Mantém mobilidade torácica sem estressar a clavícula.", when: "10 respirações · 2×/dia" },
    ],
    nutrition: {
      philosophy: "Comer como quem constrói: cada refeição é um material entregue à obra.",
      meals: [
        { time: "Manhã", desc: "Ovos com cúrcuma e pimenta-do-reino · abacate · pão de fermentação natural · suco de laranja fresco (vit. C → colágeno)" },
        { time: "Almoço", desc: "Salmão grelhado · arroz integral · brócolis · azeite extravirgem generoso" },
        { time: "Lanche", desc: "Iogurte natural · sementes de chia · frutas vermelhas (antioxidantes)" },
        { time: "Jantar", desc: "Caldo de ossos real (colágeno + minerais) · frango desfiado · legumes da estação" },
      ],
      water: "2,5 litros/dia — o metabolismo ósseo é um processo hidratado",
    },
    supplements: [
      { name: "Vitamina D₃", dose: "2.000–4.000 UI/dia", ref: "Holick, NEJM 2007" },
      { name: "Cálcio Citrato", dose: "1.000–1.200 mg/dia", ref: "Melhor biodisponibilidade que carbonato" },
      { name: "Vitamina C", dose: "500–1.000 mg/dia", ref: "Co-fator do colágeno tipo I — Padayatty, JACN 2003" },
      { name: "Magnésio Quelado", dose: "400 mg/dia", ref: "Regula cálcio + relaxa musculatura" },
      { name: "Ômega-3 (EPA/DHA)", dose: "2 g/dia", ref: "Anti-inflamatório — Calder, Ann Nutr Metab 2006" },
      { name: "Colágeno Hidrolisado", dose: "10 g/dia", ref: "Substrato direto para matriz óssea orgânica" },
    ],
    alternative: [
      "Crioterapia — gelo 15–20 min, 3×/dia, com pano sobre a incisão",
      "Aromaterapia — lavanda para dor e sono (Lakhan, Pain Research 2016)",
      "Acupressão — ponto LI4 (Hegu) na mão oposta: alivia dor no ombro",
      "Dormir semi-reclinada a 45° com travesseiro apoiando o braço",
    ],
    body: [
      "Caminhada leve — 10–15 min/dia em terreno plano",
      "Mobilização de tornozelos e panturrilhas — prevenção de trombose",
      "Isométricos de quadríceps e glúteos — 10s × 10 reps × 3×/dia",
    ],
    restNote: "Permita-se o tédio. O tédio é o silêncio onde o corpo trabalha.",
  },
  {
    id: 1,
    week: "Semanas 2 – 4",
    title: "Despertar",
    subtitle: "Mobilidade Inicial",
    epigraph: { text: "A arquitetura é o jogo sábio, correto e magnífico dos volumes reunidos sob a luz.", author: "Le Corbusier" },
    poem: "O calo ósseo é sua argamassa invisível. Já há estrutura onde antes houve fratura. O corpo sabe reconstruir — confie no projeto.",
    insight: "O osso humano em regeneração cresce seguindo as linhas de tensão mecânica — exatamente como Gaudí projetava seus arcos: a forma segue a força. Suas células osteoblásticas são pequenas arquitetas.",
    scienceNote: "Fase de calo mole → calo duro. Condrócitos formam cartilagem que será gradualmente substituída por osso lamelar. A fixação com placa permite mobilização precoce. (McKee et al., JBJS 2007; Van der Meijden, JSES 2012)",
    physio: [
      { name: "Flexão Passiva Assistida", how: "Deitada, use o braço bom para elevar o operado pelo punho. Até 90° ou limiar de dor. 5 segundos no topo.", sets: "10 repetições · 3×/dia", icon: "↑" },
      { name: "Deslizamento na Mesa", how: "Sentada à mesa de trabalho, deslize o braço sobre a superfície com um pano. O peso é suportado pela mesa.", sets: "15 repetições · 3×/dia", icon: "→" },
      { name: "Rotação Externa com Bastão", how: "Sentada, cotovelos colados ao corpo a 90°. Cabo de vassoura entre as mãos. O braço bom empurra o operado em rotação externa — 30° a 45°.", sets: "10 repetições · 3×/dia", icon: "↻" },
      { name: "Isométricos em 4 Direções", how: "Empurre a mão contra a parede: frente, lado, rotação interna e externa. 6 segundos cada. Força a 30% do máximo.", sets: "8 reps cada direção · 3×/dia", icon: "✧" },
      { name: "Estabilização Escapular W-Y", how: "Em pé, forme 'W' e 'Y' com os braços. Lado operado com amplitude reduzida. Ativa serrátil anterior e trapézio inferior.", sets: "10 repetições · 2×/dia", icon: "∧" },
    ],
    breathing: [
      { name: "Respiração + Mobilização Torácica", how: "Sentada, inspire abrindo os braços (operado com amplitude limitada). Expire retornando.", when: "8 respirações · 3×/dia" },
      { name: "Box Breathing", how: "Inspire 4s → Segure 4s → Expire 4s → Segure 4s. Usado por Navy SEALs para controle sob estresse.", when: "5 minutos · 2×/dia" },
    ],
    nutrition: {
      philosophy: "Fase osteogênica: cada refeição carrega minerais para o canteiro de obras.",
      meals: [
        { time: "Manhã", desc: "Smoothie de espinafre · banana · leite · whey protein · mel" },
        { time: "Almoço", desc: "Fígado bovino (ferro + B12) · feijão preto · couve refogada · arroz" },
        { time: "Lanche", desc: "Mix de castanhas (zinco + magnésio) · tâmaras · queijo cottage" },
        { time: "Jantar", desc: "Sardinha assada · batata-doce · folhas escuras · gergelim" },
      ],
      water: "2,5L água + 1 copo de leite enriquecido com cálcio",
    },
    supplements: [
      { name: "Vitamina D₃", dose: "2.000–4.000 UI/dia", ref: "Meta: >30 ng/mL — Bischoff-Ferrari, JAMA 2005" },
      { name: "Cálcio Citrato", dose: "1.200 mg/dia em 2 doses", ref: "Absorção otimizada" },
      { name: "Vitamina K₂ (MK-7)", dose: "100–200 mcg/dia", ref: "Direciona Ca²⁺ ao osso — Knapen 2015" },
      { name: "Zinco", dose: "15–30 mg/dia", ref: "Co-fator em 300+ enzimas de reparo" },
      { name: "Colágeno tipo I e III", dose: "10 g/dia", ref: "Substrato para matriz orgânica" },
      { name: "Probióticos", dose: "10 bilhões UFC/dia", ref: "Otimizam absorção mineral" },
    ],
    alternative: [
      "Laser de baixa intensidade (LLLT) — acelera consolidação (Fekrazad 2015)",
      "Magnetoterapia pulsada — estimulação do calo (Griffin, Cochrane 2011)",
      "Meditação Mindfulness — 10 min/dia. Reduz cortisol → acelera cicatrização",
      "Banho de sol — 15–20 min/dia (síntese de vitamina D endógena)",
    ],
    body: [
      "Caminhada — 20–30 min/dia",
      "Bicicleta ergométrica sem apoiar braços — 15 min/dia",
      "Wall sit — 3 séries × 20–30 segundos",
      "Prancha lateral (lado não operado) — 3 × 15 segundos",
    ],
    restNote: "A tipoia pode sair por períodos. Mas não tenha pressa. Le Corbusier levou 12 anos para concluir Ronchamp.",
  },
  {
    id: 2,
    week: "Semanas 4 – 6",
    title: "Construção",
    subtitle: "Amplitude Progressiva",
    epigraph: { text: "Deus está nos detalhes.", author: "Mies van der Rohe" },
    poem: "Seu calo ósseo já é estrutura. Como o aço que se revela quando a fôrma descofa, seu ombro começa a mostrar o que sempre soube fazer.",
    insight: "O osso em regeneração deposita cristais de hidroxiapatita seguindo um padrão fractal — a mesma geometria das costas do Japão, dos brócolis romanesco, da Catedral de Reims. Sua fratura está cicatrizando em fractais.",
    scienceNote: "Transição calo mole → calo duro. Mineralização ativa com deposição de hidroxiapatita. Radiografia de controle na semana 6 deve mostrar ponte óssea. (Lazarides & Zafiropoulos, JBJS-Br 2006)",
    physio: [
      { name: "ROM Ativa — Flexão e Abdução", how: "Em pé, eleve o braço ativamente. Meta: 120–150° até semana 6. Sem compensar elevando o ombro.", sets: "10 reps cada · 4×/dia", icon: "△" },
      { name: "Rotação Progressiva", how: "Deitada, cotovelo a 90°. RE para 45–60°. RI: mão atrás das costas, subindo. Progressão de 5° a cada 3–4 dias.", sets: "12 repetições · 3×/dia", icon: "↻" },
      { name: "Theraband Leve", how: "Rotação externa e interna com elástico amarelo/vermelho. Cotovelo junto ao corpo. Flexão com elástico preso ao pé.", sets: "12 reps cada · 2×/dia", icon: "≋" },
      { name: "Wall Climb", how: "'Escale' a parede com os dedos, elevando o braço progressivamente. Marque a altura — indicador visual de progresso.", sets: "3×/dia — anote a altura", icon: "▲" },
      { name: "Propriocepção", how: "Braço estendido, mão na parede com leve pressão. Pequenos círculos. Ativa proprioceptores e estabilizadores profundos.", sets: "30s cada direção · 2×/dia", icon: "◎" },
    ],
    breathing: [
      { name: "Respiração com Abdução", how: "Inspire elevando os braços lateralmente. Expire descendo. Integra mobilidade e respiração.", when: "10 repetições · 2×/dia" },
      { name: "Nadi Shodhana", how: "Respiração alternada pelas narinas. Equilibra o sistema nervoso. Promove foco e calma.", when: "5 minutos · 1×/dia" },
    ],
    nutrition: {
      philosophy: "Fase de mineralização: os cristais precisam de substrato. Alimente a obra.",
      meals: [
        { time: "Manhã", desc: "Omelete de 3 ovos com queijo · torrada integral · mamão com granola · chá verde" },
        { time: "Almoço", desc: "Frango grelhado · quinoa · abobrinha · rúcula com nozes e azeite" },
        { time: "Lanche", desc: "Pasta de amendoim · banana · leite com cacau" },
        { time: "Jantar", desc: "Sopa de lentilha com legumes · pão artesanal · queijo minas" },
      ],
      water: "2,5L água + chá verde (catequinas anti-inflamatórias)",
    },
    supplements: [
      { name: "Vitamina D₃ + K₂", dose: "2.000 UI + 100 mcg", ref: "Sinergia para mineralização" },
      { name: "Cálcio", dose: "1.000 mg/dia", ref: "Transição para manutenção" },
      { name: "Proteína total", dose: "1,2–1,5 g/kg/dia", ref: "Reconstrução muscular" },
      { name: "Curcumina + Piperina", dose: "500 mg/dia", ref: "Anti-inflamatório — Hewlings, Foods 2017" },
      { name: "Ômega-3", dose: "2 g/dia", ref: "Manutenção anti-inflamatória" },
    ],
    alternative: [
      "Hidroterapia — exercícios em piscina aquecida (após cicatrização da incisão)",
      "Acupuntura — pontos LI15, SI9, SI11, GB21 (Vickers 2012)",
      "Massagem terapêutica — trapézio, deltóide, peitoral. NÃO sobre a incisão",
      "Ultrassom pulsado (LIPUS) — evidência para consolidação (Busse 2009)",
    ],
    body: [
      "Caminhada — 30–40 min/dia, intensidade moderada",
      "Bicicleta ergométrica — 20 min/dia",
      "Prancha frontal (braços em superfície elevada) · dead bug",
      "Agachamentos livres — 3 × 12",
      "Step-ups — 3 × 10 cada perna",
    ],
    restNote: "A Sagrada Família completa 150 anos em construção. Seu osso precisa de 6 semanas. Perspectiva.",
  },
  {
    id: 3,
    week: "Semanas 6 – 8",
    title: "Estrutura",
    subtitle: "Fortalecimento Progressivo",
    epigraph: { text: "A forma segue a função.", author: "Louis Sullivan" },
    poem: "Radiografia de controle: o calo está lá. Ponte óssea visível. Você projetou edifícios — agora testemunhe o projeto mais elegante que existe: um osso que se reconstrói sob carga.",
    insight: "O osso é mais forte que concreto em compressão, peso por peso. E diferente do concreto, ele se auto-repara. Seu corpo é o material mais inteligente que existe.",
    scienceNote: "Remodelação iniciada. Osteoclastos reabsorvem osso desorganizado; osteoblastos depositam osso lamelar orientado. Lei de Wolff: o osso se fortalece nas direções de carga. Resistência progressiva ESTIMULA consolidação. (Wolff's Law; Frost, Anat Rec 1994)",
    physio: [
      { name: "Theraband Verde/Azul", how: "Progressão para elásticos de maior resistência. Flexão, abdução, rotações, extensão.", sets: "3 × 12 cada · 2×/dia", icon: "≋" },
      { name: "Elevação Lateral com Peso", how: "Haltere 0,5–1 kg. Abdução até 90°. Excêntrico lento (3s descendo) — é onde o músculo realmente se fortalece.", sets: "3 × 10 · 1×/dia", icon: "◆" },
      { name: "Push-up na Parede", how: "Mãos na parede, corpo inclinado. Quanto mais inclinada, mais carga. Progressão natural.", sets: "3 × 10 · 2×/dia", icon: "▯" },
      { name: "Remada com Elástico", how: "Elástico preso à maçaneta. Puxe com cotovelo junto ao corpo. Ativa rombóides, trapézio, infraespinhal.", sets: "3 × 12 · 2×/dia", icon: "←" },
      { name: "PNF Diagonais D1/D2", how: "Padrões de Facilitação Neuromuscular Proprioceptiva. Movimentos funcionais diagonais que mimetizam gestos reais.", sets: "10 cada padrão · 2×/dia", icon: "⟋" },
    ],
    breathing: [
      { name: "Kapalabhati Leve", how: "Expirações rápidas pelo nariz, inspiração passiva. Energizante. Ativa core sem sobrecarregar ombro.", when: "30 expirações × 3 rounds · 1×/dia" },
      { name: "Coerência Cardíaca", how: "5s inspira, 5s expira. 6 ciclos/minuto. Sincroniza coração e cérebro. Antes dos exercícios.", when: "5 min · antes de cada sessão" },
    ],
    nutrition: {
      philosophy: "Remodelação exige proteína e micronutrientes. O corpo agora está editando o projeto.",
      meals: [
        { time: "Manhã", desc: "Panqueca de banana com whey · mel · castanhas picadas · café" },
        { time: "Almoço", desc: "Carne magra · arroz com lentilha · salada com sementes · abóbora assada" },
        { time: "Lanche", desc: "Vitamina de abacate com cacau · barra de proteína" },
        { time: "Jantar", desc: "Peixe branco · purê de batata · aspargos · azeite de oliva" },
      ],
      water: "2,5L + água de coco pós-exercício",
    },
    supplements: [
      { name: "Vitamina D₃ + K₂", dose: "2.000 UI + 100 mcg", ref: "Manutenção" },
      { name: "Proteína", dose: "1,5 g/kg/dia", ref: "Fase de ganho muscular" },
      { name: "Creatina", dose: "3–5 g/dia", ref: "Recuperação de força — Branch, JISSN 2003" },
      { name: "Colágeno", dose: "10 g/dia", ref: "Suporte à remodelação contínua" },
      { name: "Magnésio", dose: "400 mg à noite", ref: "Relaxamento e qualidade do sono" },
    ],
    alternative: [
      "Pilates adaptado — foco em core, sem carga excessiva no ombro",
      "Yin Yoga — posturas restaurativas com modificações",
      "Termoterapia — calor úmido antes dos exercícios",
      "Foam roller — trapézio, dorsais, peitoral (liberação miofascial)",
    ],
    body: [
      "Caminhada intensa ou trilha leve — 40–50 min/dia",
      "Natação (crawl modificado) — se liberada pelo ortopedista",
      "Agachamento com halteres leves",
      "Lunges — 3 × 12 cada perna",
      "Prancha frontal completa — 3 × 30s",
    ],
    restNote: "Kintsugi: a arte japonesa de reparar cerâmica com ouro. A fratura reparada é mais bela que o original. Você está em kintsugi.",
  },
  {
    id: 4,
    week: "Semanas 8 – 10",
    title: "Integração",
    subtitle: "Retorno Funcional",
    epigraph: { text: "Menos é mais.", author: "Mies van der Rohe" },
    poem: "Há um momento em que a obra deixa de ser canteiro e se torna espaço. Seu ombro está nessa transição. O gesto retorna. O traço no papel. O volante. A xícara de café com a mão direita.",
    insight: "A clavícula é o único osso longo horizontal do corpo e o primeiro a ossificar no embrião (5ª semana) e o último a completar (25 anos). Você está refazendo uma das primeiras estruturas da sua existência.",
    scienceNote: "Remodelação ativa segundo Lei de Wolff. Resistência óssea atinge 80–90% em 8–10 semanas pós-ORIF. Retorno a atividades funcionais leves a moderadas. (Court-Brown & Caesar, Injury 2006)",
    physio: [
      { name: "Cadeia Cinética Fechada", how: "Push-up inclinado, bear crawl estático, prancha com apoio de mãos. Mais segura e funcional.", sets: "3 × 10 cada · 1×/dia", icon: "▣" },
      { name: "Exercícios Overhead", how: "Elevação acima da cabeça com 1–2 kg. Pressão overhead sentada. Progredir conforme tolerância.", sets: "3 × 10 · 1×/dia", icon: "⬆" },
      { name: "Propriocepção Avançada", how: "Apoio na mão sobre superfície instável (almofada). Desafios de controle neuromuscular.", sets: "3 × 30s · 2×/dia", icon: "◎" },
      { name: "Gestos Funcionais", how: "Simule seu dia: alcançar prateleiras, dirigir, carregar maquetes. Desenhar, usar mouse. Treine O QUE VOCÊ precisa.", sets: "Integrar ao longo do dia", icon: "✎" },
    ],
    breathing: [
      { name: "Respiração de Flow State", how: "Inspire 4s nariz, expire 6s boca. Expiração prolongada ativa foco profundo — ideal para voltar a projetar.", when: "5 min antes de trabalhar" },
    ],
    nutrition: {
      philosophy: "Manutenção e energia para atividade crescente. Alimente o retorno.",
      meals: [
        { time: "Manhã", desc: "Aveia com frutas e canela · ovos · café · suco verde" },
        { time: "Almoço", desc: "Bowl de salmão · edamame · arroz · gengibre · gergelim" },
        { time: "Lanche", desc: "Frutas da estação · iogurte grego · granola caseira" },
        { time: "Jantar", desc: "Risoto de cogumelos · salada verde · azeite trufado" },
      ],
      water: "2–2,5L/dia + hidratação pós-atividade",
    },
    supplements: [
      { name: "Vitamina D₃", dose: "2.000 UI/dia", ref: "Manutenção" },
      { name: "Magnésio", dose: "400 mg", ref: "Recuperação muscular e sono" },
      { name: "Ômega-3", dose: "1–2 g/dia", ref: "Anti-inflamatório de manutenção" },
      { name: "Colágeno", dose: "10 g/dia", ref: "Até completar 12 semanas" },
    ],
    alternative: [
      "Yoga vinyasa adaptada — retorno a sequências com peso nos braços",
      "Tai Chi — equilíbrio, coordenação e movimentos suaves",
      "Massagem esportiva — preparação para retorno pleno",
      "Visualização — imagine-se projetando, desenhando, construindo",
    ],
    body: [
      "Corrida leve — 20–30 min",
      "Natação completa — todos os estilos",
      "Treino de força upper body moderado",
      "Aula de Pilates ou funcional completa",
    ],
    restNote: "Tadao Ando: 'A arquitetura é o domínio da luz no espaço.' Você está reencontrando a luz do seu movimento.",
  },
  {
    id: 5,
    week: "Semanas 10 – 12+",
    title: "Plenitude",
    subtitle: "Retorno Completo",
    epigraph: { text: "A simplicidade é a sofisticação suprema.", author: "Leonardo da Vinci" },
    poem: "Doze semanas. O osso agora é mais denso onde fraturou. A placa permanece, mas é seu osso que carrega. Você reconstruiu o que sustenta — e aprendeu que parar também é um ato de construção.",
    insight: "O corpo humano substitui todo o esqueleto a cada 10 anos. Daqui a uma década, nenhum átomo de cálcio desta fratura estará lá. Mas a memória da paciência, sim.",
    scienceNote: "Consolidação esperada em 10–12 semanas pós-ORIF. Remodelação continua 1–2 anos. Placa pode ser removida após 12–18 meses se sintomática, mas geralmente permanece. Retorno pleno sem restrição. (Virtanen, Acta Orthop 2012; AAOS Guidelines)",
    physio: [
      { name: "Treino de Força Pleno", how: "Todos os exercícios sem restrição de amplitude. Supino, desenvolvimento, remada, pull-down. Progressão de carga.", sets: "Programa livre", icon: "◈" },
      { name: "Pliometria Leve", how: "Medicine ball throws. Flexão explosiva. Introdução gradual de impacto.", sets: "3 × 8 · 2×/semana", icon: "⚡" },
      { name: "Mobilidade — Manutenção", how: "Rotina matinal de 5 min: círculos de ombro, rotações, pass-throughs com bastão. Mantenha a amplitude conquistada.", sets: "Diariamente, como ritual", icon: "∞" },
    ],
    breathing: [
      { name: "Respiração de Celebração", how: "Inspire profundamente com os braços elevados ao máximo. Expire sorrindo. Sinta a amplitude completa. Você reconquistou isso.", when: "Sempre que quiser" },
    ],
    nutrition: {
      philosophy: "Liberdade com consciência. Você aprendeu a nutrir uma reconstrução. Agora nutra a vida.",
      meals: [
        { time: "Manhã", desc: "O que seu corpo pedir — com a sabedoria dos últimos 3 meses" },
        { time: "Almoço", desc: "Dieta mediterrânea como base — a mais evidenciada para saúde óssea" },
        { time: "Lanche", desc: "Frutas, castanhas, laticínios — os hábitos que você construiu" },
        { time: "Jantar", desc: "Celebre. Cozinhe com as duas mãos. Isso também é reabilitação." },
      ],
      water: "Mantenha hidratação como hábito permanente",
    },
    supplements: [
      { name: "Vitamina D₃", dose: "1.000–2.000 UI/dia", ref: "Manutenção por vida" },
      { name: "Magnésio", dose: "300–400 mg/dia", ref: "Benefício permanente" },
      { name: "Colágeno", dose: "Opcional: 5–10 g/dia", ref: "Pele, articulações, cabelo" },
    ],
    alternative: [
      "Qualquer prática que te faça feliz — yoga, dança, escalada",
      "Mindfulness como prática de vida",
      "Massagem mensal preventiva",
      "Consulta ortopédica aos 6 e 12 meses",
    ],
    body: [
      "Sem restrições — retorno pleno a todas as atividades",
      "Treino de musculação completo",
      "Esportes, viagens, vida",
      "Continue se movendo — o osso agradece com densidade",
    ],
    restNote: "Como escreveu Fernando Pessoa: 'Primeiro estranha-se, depois entranha-se.' Você estranhará não ter a tipoia. Depois lembrará que sempre soube voar.",
  },
];

const SECTIONS = [
  { key: "physio", icon: "◐", label: "Reabilitação", title: "Exercícios de Fisioterapia" },
  { key: "breathing", icon: "○", label: "Respiração", title: "Práticas Respiratórias" },
  { key: "nutrition", icon: "◑", label: "Nutrição", title: "Alimentação & Hidratação" },
  { key: "supplements", icon: "◒", label: "Suplementação", title: "Vitaminas & Minerais" },
  { key: "alternative", icon: "◓", label: "Holístico", title: "Terapias Complementares" },
  { key: "body", icon: "◔", label: "Movimento", title: "Atividade Física Geral" },
];

export default function App() {
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(null);
  const mainRef = useRef(null);

  useEffect(() => {
    setOpen(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [active]);

  const p = PHASES[active];
  const toggle = (s) => setOpen(open === s ? null : s);

  return (
    <>
      <style>{FONTS_CSS}{`
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
        html{font-size:16px;scroll-behavior:smooth}
        body{background:#FAF9F6;color:#1A1A18;font-family:'DM Sans',system-ui,sans-serif;-webkit-font-smoothing:antialiased}

        .wrap{max-width:780px;margin:0 auto;padding:0 1.5rem}

        /* HERO */
        header{background:#1A1A18;color:#FAF9F6;padding:5rem 0 4rem;position:relative;overflow:hidden}
        header::before{content:'';position:absolute;top:-50%;right:-20%;width:600px;height:600px;border:1px solid rgba(250,249,246,0.04);border-radius:50%;pointer-events:none}
        header::after{content:'';position:absolute;bottom:-30%;left:-10%;width:400px;height:400px;border:1px solid rgba(250,249,246,0.03);border-radius:50%;pointer-events:none}
        .h-tag{font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:.35em;text-transform:uppercase;color:rgba(250,249,246,.3);margin-bottom:2rem}
        .h-title{font-family:'Cormorant Garamond',serif;font-weight:300;font-size:clamp(2.2rem,5.5vw,3.8rem);line-height:1.1;letter-spacing:-.03em;margin-bottom:1rem}
        .h-title em{font-style:italic;color:rgba(250,249,246,.5)}
        .h-desc{font-size:.85rem;font-weight:300;color:rgba(250,249,246,.45);max-width:500px;line-height:1.8}
        .h-grid{display:flex;gap:2.5rem;flex-wrap:wrap;margin-top:2.5rem}
        .h-meta{font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.12em;color:rgba(250,249,246,.25)}
        .h-meta span{display:block;font-size:.7rem;color:rgba(250,249,246,.6);margin-top:.2rem;letter-spacing:0}

        /* NAV */
        nav{background:#F3F1EC;border-bottom:1px solid rgba(26,26,24,.06);position:sticky;top:0;z-index:100;overflow-x:auto;-webkit-overflow-scrolling:touch}
        nav::-webkit-scrollbar{display:none}
        .nav-inner{max-width:780px;margin:0 auto;display:flex;padding:0 1rem}
        .tab{flex:0 0 auto;padding:1.1rem 1.3rem .9rem;background:none;border:none;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.18em;text-transform:uppercase;color:rgba(26,26,24,.28);border-bottom:1.5px solid transparent;transition:all .25s;white-space:nowrap}
        .tab:hover{color:rgba(26,26,24,.55)}
        .tab.on{color:#1A1A18;border-bottom-color:#1A1A18}

        /* MAIN */
        main{padding:3.5rem 0 5rem}

        /* PHASE HEAD */
        .ph-wk{font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.35em;text-transform:uppercase;color:rgba(26,26,24,.28);margin-bottom:.6rem}
        .ph-t{font-family:'Cormorant Garamond',serif;font-weight:300;font-size:clamp(2rem,4.5vw,3.2rem);letter-spacing:-.025em;line-height:1.08}
        .ph-st{font-weight:300;font-size:.85rem;color:rgba(26,26,24,.4);margin-top:.3rem}

        /* PROGRESS */
        .prog{display:flex;align-items:center;gap:.4rem;margin-top:2rem;padding-top:1.5rem;border-top:1px solid rgba(26,26,24,.06)}
        .dot{width:7px;height:7px;border-radius:50%;background:rgba(26,26,24,.08);transition:all .3s}
        .dot.on{background:#1A1A18;transform:scale(1.3)}
        .dot.done{background:rgba(26,26,24,.25)}
        .line{flex:1;height:1px;background:rgba(26,26,24,.06)}

        /* EPIGRAPH */
        .epi{margin:3rem 0;padding:2.5rem 0;border-top:1px solid rgba(26,26,24,.06);border-bottom:1px solid rgba(26,26,24,.06)}
        .epi-q{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:1.4rem;font-weight:300;line-height:1.5;color:#1A1A18}
        .epi-a{font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.25em;text-transform:uppercase;color:rgba(26,26,24,.28);margin-top:.8rem}

        /* TEXT BLOCKS */
        .blk{font-weight:300;font-size:.88rem;line-height:1.85;color:rgba(26,26,24,.65);margin-bottom:1.5rem}
        .blk.poem{font-family:'Cormorant Garamond',serif;font-size:1.05rem;font-style:italic;color:rgba(26,26,24,.5);border-left:2px solid rgba(26,26,24,.08);padding-left:1.5rem;margin:2rem 0}
        .blk.ins{background:rgba(26,26,24,.025);padding:1.3rem 1.5rem;border-radius:3px;font-size:.84rem;position:relative}
        .blk.ins::before{content:'⌘';position:absolute;top:1.3rem;right:1.5rem;font-size:.75rem;color:rgba(26,26,24,.12)}
        .blk.sci{font-family:'JetBrains Mono',monospace;font-size:.67rem;line-height:2;color:rgba(26,26,24,.35);padding:1.3rem 1.5rem;background:rgba(26,26,24,.018);border-left:2px solid rgba(26,26,24,.05)}

        /* ACCORDION */
        .acc{margin-top:3rem}
        .acc-btn{width:100%;background:none;border:none;cursor:pointer;padding:1.2rem 0;display:flex;align-items:center;justify-content:space-between;border-top:1px solid rgba(26,26,24,.06);transition:padding .2s}
        .acc-btn:hover{padding-left:.4rem}
        .acc-left{display:flex;align-items:center;gap:1rem}
        .acc-ico{font-size:.9rem;width:2.2rem;height:2.2rem;display:flex;align-items:center;justify-content:center;background:rgba(26,26,24,.03);border-radius:50%;font-family:'JetBrains Mono',monospace}
        .acc-lbl{font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.2em;text-transform:uppercase;color:rgba(26,26,24,.35)}
        .acc-ttl{font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-weight:400;color:#1A1A18;margin-top:.05rem}
        .acc-arr{font-size:1.1rem;color:rgba(26,26,24,.2);transition:transform .3s;font-weight:300;font-family:'JetBrains Mono',monospace}
        .acc-arr.open{transform:rotate(45deg)}
        .acc-body{padding:0 0 1.5rem;animation:fadeUp .3s ease}
        @keyframes fadeUp{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}

        /* EXERCISE */
        .ex{padding:1.1rem 0;border-bottom:1px solid rgba(26,26,24,.03)}
        .ex:last-child{border:none}
        .ex-top{display:flex;align-items:flex-start;gap:.7rem}
        .ex-i{font-family:'JetBrains Mono',monospace;font-size:.85rem;width:1.8rem;text-align:center;color:rgba(26,26,24,.22);flex-shrink:0;margin-top:.1rem}
        .ex-n{font-weight:500;font-size:.84rem}
        .ex-h{font-weight:300;font-size:.82rem;color:rgba(26,26,24,.55);line-height:1.75;margin-top:.4rem;padding-left:2.5rem}
        .ex-s{font-family:'JetBrains Mono',monospace;font-size:.58rem;letter-spacing:.08em;color:rgba(26,26,24,.3);margin-top:.4rem;padding-left:2.5rem}

        /* BREATHING */
        .br{padding:1rem 0;border-bottom:1px solid rgba(26,26,24,.03)}
        .br:last-child{border:none}
        .br-n{font-weight:500;font-size:.84rem}
        .br-h{font-weight:300;font-size:.82rem;color:rgba(26,26,24,.55);line-height:1.75;margin-top:.35rem}
        .br-w{font-family:'JetBrains Mono',monospace;font-size:.58rem;color:rgba(26,26,24,.3);margin-top:.35rem}

        /* SUPPLEMENTS */
        .sp{display:grid;grid-template-columns:1fr auto 1fr;gap:.3rem 1rem;padding:.7rem 0;border-bottom:1px solid rgba(26,26,24,.03);align-items:baseline}
        .sp:last-child{border:none}
        .sp-n{font-weight:500;font-size:.84rem}
        .sp-d{font-family:'JetBrains Mono',monospace;font-size:.6rem;color:rgba(26,26,24,.4);text-align:center}
        .sp-r{font-size:.75rem;font-weight:300;color:rgba(26,26,24,.35);text-align:right}

        /* MEALS */
        .ml-ph{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:1rem;color:rgba(26,26,24,.45);margin-bottom:1.2rem}
        .ml{padding:.7rem 0;border-bottom:1px solid rgba(26,26,24,.03)}
        .ml:last-child{border:none}
        .ml-t{font-family:'JetBrains Mono',monospace;font-size:.5rem;letter-spacing:.25em;text-transform:uppercase;color:rgba(26,26,24,.22);margin-bottom:.2rem}
        .ml-d{font-size:.84rem;font-weight:300;color:rgba(26,26,24,.55);line-height:1.65}
        .ml-w{font-family:'JetBrains Mono',monospace;font-size:.6rem;color:rgba(26,26,24,.28);margin-top:1rem;padding-top:.7rem;border-top:1px solid rgba(26,26,24,.04)}

        /* SIMPLE LIST */
        .sl{font-size:.84rem;font-weight:300;color:rgba(26,26,24,.55);line-height:1.75;padding:.45rem 0 .45rem 1rem;border-left:1px solid rgba(26,26,24,.05);margin-bottom:.4rem}

        /* REST */
        .rest{margin-top:3.5rem;padding:2.2rem 2rem;background:#1A1A18;color:#FAF9F6}
        .rest-lbl{font-family:'JetBrains Mono',monospace;font-size:.5rem;letter-spacing:.35em;text-transform:uppercase;color:rgba(250,249,246,.25);margin-bottom:.8rem}
        .rest-txt{font-family:'Cormorant Garamond',serif;font-size:1.1rem;font-weight:300;line-height:1.75;color:rgba(250,249,246,.75);font-style:italic}

        /* DISCLAIMER */
        .disc{margin-top:2.5rem;padding:1.3rem 1.5rem;border:1px solid rgba(26,26,24,.06);font-size:.68rem;font-weight:300;color:rgba(26,26,24,.32);line-height:1.9}

        /* NAV BTNS */
        .navb{display:flex;justify-content:space-between;margin-top:2.5rem;gap:1rem}
        .btn{background:none;border:1px solid rgba(26,26,24,.12);padding:.75rem 1.5rem;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:.6rem;letter-spacing:.15em;text-transform:uppercase;color:rgba(26,26,24,.45);transition:all .2s}
        .btn:hover{border-color:rgba(26,26,24,.3);color:rgba(26,26,24,.7)}
        .btn.pri{background:#1A1A18;border-color:#1A1A18;color:#FAF9F6}
        .btn.pri:hover{background:#333}

        footer{padding:3rem 0;background:#1A1A18;color:rgba(250,249,246,.2);text-align:center;font-family:'JetBrains Mono',monospace;font-size:.55rem;letter-spacing:.12em;line-height:2.2}

        @media(max-width:640px){
          .wrap{padding:0 1.25rem}
          header{padding:3rem 0 2.5rem}
          .sp{grid-template-columns:1fr;gap:.1rem}
          .sp-d,.sp-r{text-align:left}
          .h-grid{gap:1.5rem}
        }
      `}</style>

      <div>
        <header>
          <div className="wrap">
            <div className="h-tag">Protocolo de Recuperação Pós-Cirúrgico</div>
            <h1 className="h-title">Reconstrução<br/><em>Clavícula — ORIF</em></h1>
            <p className="h-desc">Doze semanas que combinam rigor ortopédico com sabedoria holística. Projetado como você projeta: com estrutura, intenção e beleza.</p>
            <div className="h-grid">
              <div className="h-meta">Procedimento<span>ORIF — Placa + Parafusos</span></div>
              <div className="h-meta">Cirurgia<span>23 Março 2026</span></div>
              <div className="h-meta">Lado<span>Clavícula Direita (dominante)</span></div>
              <div className="h-meta">Duração<span>6 fases · 12 semanas</span></div>
            </div>
          </div>
        </header>

        <nav>
          <div className="nav-inner">
            {PHASES.map((ph,i)=>(
              <button key={i} className={`tab ${active===i?"on":""}`} onClick={()=>setActive(i)}>
                {ph.title}
              </button>
            ))}
          </div>
        </nav>

        <main ref={mainRef}>
          <div className="wrap">
            <div className="ph-wk">{p.week}</div>
            <h2 className="ph-t">{p.title}</h2>
            <div className="ph-st">{p.subtitle}</div>

            <div className="prog">
              {PHASES.map((_,i)=>(
                <React.Fragment key={i}>
                  <div className={`dot ${i===active?"on":i<active?"done":""}`}/>
                  {i<PHASES.length-1&&<div className="line"/>}
                </React.Fragment>
              ))}
            </div>

            <div className="epi">
              <div className="epi-q">"{p.epigraph.text}"</div>
              <div className="epi-a">— {p.epigraph.author}</div>
            </div>

            <div className="blk poem">{p.poem}</div>
            <div className="blk ins">{p.insight}</div>
            <div className="blk sci">{p.scienceNote}</div>

            <div className="acc">
              {SECTIONS.map(sec=>{
                const isOpen = open===sec.key;
                return (
                  <div key={sec.key}>
                    <button className="acc-btn" onClick={()=>toggle(sec.key)}>
                      <div className="acc-left">
                        <div className="acc-ico">{sec.icon}</div>
                        <div>
                          <div className="acc-lbl">{sec.label}</div>
                          <div className="acc-ttl">{sec.title}</div>
                        </div>
                      </div>
                      <span className={`acc-arr ${isOpen?"open":""}`}>+</span>
                    </button>
                    {isOpen && (
                      <div className="acc-body">
                        {sec.key==="physio" && p.physio.map((ex,i)=>(
                          <div className="ex" key={i}>
                            <div className="ex-top">
                              <div className="ex-i">{ex.icon}</div>
                              <div className="ex-n">{ex.name}</div>
                            </div>
                            <div className="ex-h">{ex.how}</div>
                            <div className="ex-s">{ex.sets}</div>
                          </div>
                        ))}
                        {sec.key==="breathing" && p.breathing.map((b,i)=>(
                          <div className="br" key={i}>
                            <div className="br-n">{b.name}</div>
                            <div className="br-h">{b.how}</div>
                            <div className="br-w">{b.when}</div>
                          </div>
                        ))}
                        {sec.key==="nutrition" && (
                          <>
                            <div className="ml-ph">{p.nutrition.philosophy}</div>
                            {p.nutrition.meals.map((m,i)=>(
                              <div className="ml" key={i}>
                                <div className="ml-t">{m.time}</div>
                                <div className="ml-d">{m.desc}</div>
                              </div>
                            ))}
                            <div className="ml-w">💧 {p.nutrition.water}</div>
                          </>
                        )}
                        {sec.key==="supplements" && p.supplements.map((s,i)=>(
                          <div className="sp" key={i}>
                            <div className="sp-n">{s.name}</div>
                            <div className="sp-d">{s.dose}</div>
                            <div className="sp-r">{s.ref}</div>
                          </div>
                        ))}
                        {sec.key==="alternative" && p.alternative.map((a,i)=>(
                          <div className="sl" key={i}>{a}</div>
                        ))}
                        {sec.key==="body" && p.body.map((b,i)=>(
                          <div className="sl" key={i}>{b}</div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="rest">
              <div className="rest-lbl">Pausa & Restauração</div>
              <div className="rest-txt">{p.restNote}</div>
            </div>

            <div className="disc">⚕️ Este plano é informativo e baseado em literatura ortopédica (McKee/JBJS, Einhorn/Nature Reviews, AAOS Guidelines). Não substitui acompanhamento médico. Progressões devem ser validadas pelo seu ortopedista e fisioterapeuta. Protocolo para: ORIF clavícula direita — 23/03/2026.</div>

            <div className="navb">
              {active>0 ? <button className="btn" onClick={()=>setActive(active-1)}>← Anterior</button> : <div/>}
              {active<PHASES.length-1 ? <button className="btn pri" onClick={()=>setActive(active+1)}>Próxima fase →</button> : <div/>}
            </div>
          </div>
        </main>

        <footer>
          <div className="wrap">
            Protocolo Pós-ORIF Clavícula · 12 Semanas · 2026<br/>
            Referências: McKee (JBJS) · Einhorn (Nature Reviews) · Van der Meijden (JSES) · AAOS<br/><br/>
            "A arquitetura começa quando você coloca dois tijolos juntos com cuidado."<br/>— Mies van der Rohe
          </div>
        </footer>
      </div>
    </>
  );
}
